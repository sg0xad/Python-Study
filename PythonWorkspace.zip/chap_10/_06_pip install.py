# pip install

# PyPI 사이트에서 원하는 패키지를 설치할 수 있다.
# 해당 코드 예제는 pip install beautifulsoup4
# pip list // 현재 설치되어있는 패키지 목록 출력
# pip show 패키지명 // 패키지에 대한 정보를 출력
# pip install --upgrade 패키지명 // 패키지를 최신버전으로 업그레이드
# pip uninstall 패키지명 // 패키지 삭제

# from bs4 import BeautifulSoup
# soup = BeautifulSoup("<p>Some<b>bad<i>HTML")
# print(soup.prettify())