from random import *

a = randint(10, 99)
b = randint(10, 99)

print(f"{a} + {b} = ", end="")
input1 = int(input())
if (input1 == a+b):
    print("정답")
else:
    print("오답")

print(f"{a} - {b} = ", end="")
input2 = int(input())
if (input2 == a-b):
    print("정답")
else:
    print("오답")

print(f"{a} * {b} = ", end="")
input3 = int(input())
if (input3 == a*b):
    print("정답")
else:
    print("오답")

print(f"{a} / {b} = ", end="")
input4 = int(input())
if (input4 == a/b):
    print("정답")
else:
    print("오답")