import math

# 수학에서 나타나는 수식을 파이썬의 수식 형태로 바꾸어보자.

print("x^4 - 9x^3 + ^2")
x = int(input("x를 입력하시오:  "))
print(x**4 - 9*x**3 + x**2)

print("4/3*π*r^3")
r = int(input("반지름을 입력하세요: "))
print((4/3) * math.pi * r**3)

a = int(input("a를 입력하시오: "))
b = int(input("b를 입력하시오: "))
c = int(input("c를 입력하시오: "))

x1 = (-b + math.sqrt(b**2 - 4*a*c)) / (2*a)
x2 = (-b - math.sqrt(b**2 - 4*a*c)) / (2*a)

print("2차 방정식의 해는 {}, {} 입니다.".format(x1, x2))