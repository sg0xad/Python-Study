# 자동 판매기

money = int(input("투입한 돈: "))

price = int(input("물건값: "))

change = money-price # 거스름돈 결과

print("거스름돈: {}".format(change))

money500 = change // 500 # 거스름돈에 맞게 500원으로 나눔

change = change % 500 
 
money100 = change // 100 # 거스름돈에서 500으로 나눈 나머지를 100원으로 나눔

print("500원 동전의 개수: {}".format(money500))

print("100원 동전의 개수: {}".format(money100))