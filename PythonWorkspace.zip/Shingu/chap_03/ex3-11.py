import time

total_sec = time.time() # total_sec에 1970년 1월 1일이후 흘러온 전체 초값이 저장됨

# total_sec은 실수라서 정수로 변환해줌
sec = int(total_sec)

# 현재 분(minute)와 시간(hour) 계산
current_minute = sec // 60 % 60
current_hour = sec // 3600 % 24

print(f'현재시간(GMT) : {current_hour}시 {current_minute}분')