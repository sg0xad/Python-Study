
# 사용자로부터 입력받기
input = int(input("변환할 초를 입력하세요:"))

min = input // 60
hour = min // 60

sec = input % 60
min = min % 60


print("화면에 입력한 {}초는 {}시간 {}분 {}초 입니다".format(input, hour, min, sec))

