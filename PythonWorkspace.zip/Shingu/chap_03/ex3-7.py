numbers = int(input())

sum = numbers % 10
sum += numbers // 10 % 10
sum += numbers // 100 % 10
sum += numbers // 1000 % 10

print("자릿수의 합: ", sum)

