import turtle as t
t.shape("turtle") # 거북이 모양으로
t.goto(-150, 0) # 좌표 (-150, 0)으로 이동
t.forward(300)
t.left(90)
t.forward(100)
t.left(90)
t.forward(300)
t.left(90)
t.forward(100)

t.up()              # 펜을 들어서 거북이가 움직이더라도 그림이 그려지지 않게 한다.
t.goto(-150, 0)
t.down()            # 펜을 내린다
t.fillcolor("blue")
t.begin_fill()
t.circle(50)
t.end_fill()
t.up()
t.goto(50, 0)
t.down()
t.fillcolor("orange")
t.begin_fill()
t.circle(50)
t.end_fill()
t.done() # 터틀 그래픽 종료 (안쓰면 자동 종료)