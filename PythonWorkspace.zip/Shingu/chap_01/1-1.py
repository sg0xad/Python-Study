# 사각형, 삼각형, 오각형 만들기
import turtle
t = turtle.Turtle()
t.up()
t.goto(-60, 200)
t.down()
t.shape("turtle") # 거북이 모양으로
t.fillcolor("blue") # t.color도 가능
t.begin_fill()
t.forward(100)  # 앞으로 100픽셀 전진
t.right(90)     # 오른쪽으로 90도 회전
t.forward(100)
t.right(90)
t.forward(100)
t.right(90)
t.forward(100)
t.right(90)
t.forward(100)
t.end_fill()

t.up()
t.goto(0, 0)
t.down()
t.fillcolor("red")
t.begin_fill()
t.right(60)
t.forward(100)
t.right(120)
t.forward(100)
t.right(120)
t.forward(100)
t.end_fill()

t.up()
t.goto(-60, -200)
t.down()
t.fillcolor("yellow")
t.begin_fill()
t.right(60)
t.forward(100)
t.right(72)
t.forward(100)
t.right(72)
t.forward(100)
t.right(72)
t.forward(100)
t.right(72)
t.forward(100)
t.end_fill()


turtle.done() # 터틀 그래픽 종료 (안쓰면 자동 종료)