# 원 그리기
import turtle as t
t.shape("turtle")

t.fillcolor("blue") # 채우는 색상 지정
t.begin_fill()      # 채우기 시작
t.circle(100)       # 반지름이 100인 원이 그려진다.
t.end_fill()        # 채우기 종료