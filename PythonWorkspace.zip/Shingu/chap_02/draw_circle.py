import turtle as t
radius = 50

t.circle(radius)
t.up()
t.goto(100, 0)
t.down()
t.circle(radius*2)
t.up()
t.goto(200, 0)
t.down()
t.circle(radius*3)

t.done()
