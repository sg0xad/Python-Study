a = int(input())
b = int(input())
c = int(input())

sum = a+b+c

print("총합 {}".format(sum))
print("평균 {}".format(sum/3))