import turtle as t

t.pensize(10)
t.color("yellow")
t.up()
t.goto(-100, 0)
t.down()
t.circle(50)

t.up()
t.goto(0, 0)
t.color("green")
t.down()
t.circle(50)

t.up()
t.goto(-150, 70)
t.color("blue")
t.down()
t.circle(50)

t.up()
t.goto(-50, 70)
t.color("black")
t.down()
t.circle(50)

t.up()
t.goto(50, 70)
t.color("red")
t.down()
t.circle(50)

t.done()





