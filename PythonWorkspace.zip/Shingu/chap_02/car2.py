# 화면 중앙에 자동차를 그림

import turtle as t

# 펜촉을 거북모양으로 한다. 펜촉은 (0,0)에 위치하면 방향은 오른쪽이다
t.shape("turtle")

# 사용자로부터 사이즈 입력 받기
size = int(input("자동차 크기를 입력하세요: "))

# 사각형 2개 길이, 타이어 반지름 길이
Dx = size * 2
Dy = size
dx = size
dy = size / 2
rad = size / 4
angle = 90

# 자동차가 창 중심에 있도록 펜촉을 이동한다
t.up()
t.goto(-Dx / 2, -Dy / 2)  # 펜촉 왼쪽으로 이동
t.down()  # 펜을 내린다.

# 자동차 몸체 색상을 red로 지정하고, 채우기 시작하고, 몸체를 그린다.
t.fillcolor("red")
t.begin_fill()
t.forward(Dx)
t.left(angle)
t.forward(Dy)
t.left(angle)
t.forward(Dx)
t.left(angle)
t.forward(Dy)
t.end_fill()

# 자동차 상체그리기 위해 좌표이동
t.up()
t.goto(-Dx / 4, Dy / 2)  # 펜촉 왼쪽으로 이동
t.down()  # 펜을 내린다.

# 자동차 상체 색상을 yello로 지정하고, 채우기 시작하고, 몸체를 그린다.
t.fillcolor("yellow")
t.begin_fill()

t.right(angle + angle)  # 펜촉을 위로 향하게 방향 조절
t.forward(dy)
t.right(angle)
t.forward(dx)
t.right(angle)
t.forward(dy)
t.right(angle)
t.forward(dx)

t.end_fill()

# 타이어색상을 black으로 지정하고, 채우기 시작하고, 타이어를 그린다
t.up()
t.goto(-(Dx / 4 + rad), -Dy / 2)  # 펜촉을 왼쪽으로 이동
t.left(angle)
t.down()

t.fillcolor("black")
t.begin_fill()
t.circle(rad)  # 원을 그린다.

t.up()
t.goto(Dx / 4 - rad, -Dy / 2)
t.down()

t.circle(rad)
t.end_fill()

t.done()