import turtle

# 사용자로부터 집의 크기를 입력받음
size = int(input("집의 크기를 입력하세요: "))

# 터틀 객체 생성
t = turtle.Turtle()

# 집 그리기
t.forward(size)
t.right(90)
t.forward(size)
t.right(90)
t.forward(size)
t.right(90)
t.forward(size)

# 지붕 그리기
t.right(30)
t.forward(size)
t.right(120)
t.forward(size)
t.right(120)
t.forward(size)

turtle.done()