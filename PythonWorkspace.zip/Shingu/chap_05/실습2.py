import random

print("주사위 굴리기 게임을 시작합니다.")
dice = random.randrange(1, 7)
print(f"결과는 {dice}입니다.")
print("게임이 종료되었습니다.")