import turtle as t

# 사용자로부터 입력 받기
shape = input("도형의 종류를 입력하세요 (3~6각형, 원): ")
size = int(input("도형의 크기를 입력하세요: "))
color = input("도형의 색깔을 입력하세요: ")

# 도형 그리기 설정
t.color(color)

if shape == '원':
    t.circle(size)
else:
    sides = int(shape[0])  # 각수 추출 (예: "3각형"에서 "3" 추출)
    angle = 360 / sides

    for _ in range(sides):
        t.forward(size)
        t.right(angle)

t.done()