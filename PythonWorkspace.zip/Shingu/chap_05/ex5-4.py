score = int(input("성적을 입력하시오 : "))

if score > 100:
    print("범위에 없습니다")
elif score >= 90:
    print("A")
elif score >= 80:
    print("B")
elif score >= 70:
    print("C")
elif score >= 60:
    print("D")
elif 60 > score >= 0:
    print("F")
else:
    print("범위에 없습니다.")