from random import *
user = input()
computer = randint(0, 2)
if computer == 0:
    computer = "가위"
elif computer == 1:
    computer = "바위"
elif computer == 2:
    computer = "보"

if user == "가위" and computer == "가위":
    print("무승부")
elif user == "가위" and computer == "바위":
    print("컴퓨터가 이겼습니다.")
elif user == "가위" and computer == "보":
    print("사용자가 이겼습니다.")
elif user == "바위" and computer == "바위":
    print("무승부")
elif user == "바위" and computer == "보":
    print("컴퓨터가 이겼습니다.")
elif user == "바위" and computer =="가위":
    print("사용자가 이겼습니다.")
elif user =="보" and computer =="보":
    print("무승부")
elif user =="보" and computer =="바위":
    print("사용자가 이겼습니다.")
else: #user=="보",computer=="가위"
   print("컴퓨터가 이겼습니다.")