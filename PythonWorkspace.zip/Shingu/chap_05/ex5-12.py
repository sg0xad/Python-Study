year = int(input("출생 연도의 끝자리를 입력하세요: "))

if year % 5 == 0:
    print("월요일")
elif year % 5 == 1:
    print("화요일")
elif year % 5 == 2:
    print("수요일")
elif year % 5 == 3:
    print("목요일")
else:
    print("금요일")