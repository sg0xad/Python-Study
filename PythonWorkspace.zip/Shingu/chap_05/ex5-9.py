import random
luck = random.randint(1, 100)

num = int(input("복권번호를 입력해주세요 : "))

print("당첨번호는", luck, "입니다.")

digit1 = luck//10
digit2 = luck%10

number1 = num//10
number2 = num%10

if(luck == num):
    print("상금은 100만원입니다.")
elif(digit1 == number1 or digit1 == number2 or digit2 == number1 or digit2 == number2):
    print("상금은 50만원입니다.")
else:
    print("상금은 없습니다.")