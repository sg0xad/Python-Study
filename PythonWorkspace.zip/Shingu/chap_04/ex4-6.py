a = int(input("정수를 입력하시오 : "))
b = int(input("정수를 입력하시오 : "))
c = int(input("정수를 입력하시오 : "))

list = []

list.append(a)
list.append(b)
list.append(c)

print("리스트 = [{}, {}, {}]".format(list[0], list[1], list[2]))

print("리스트 숫자들의 합 = {}".format(list[0] + list[1] + list[2]))