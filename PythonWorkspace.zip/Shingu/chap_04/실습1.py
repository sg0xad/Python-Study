# 학생 정보를 저장할 리스트
students = []

# 3명의 학생 정보 입력 받기
for _ in range(3):
    name = input("성명: ")
    kor = int(input("국어 점수: "))
    eng = int(input("영어 점수: "))
    math = int(input("수학 점수: "))

    students.append({
        'name': name,
        'kor': kor,
        'eng': eng,
        'math': math,
        'total': kor + eng + math,
        'avg': (kor + eng + math) / 3.0
    })

print("\n성명 국어 영어 수학 총점 평균")
for student in students:
    print(f"{student['name']} {student['kor']} {student['eng']} {student['math']} {student['total']} {student['avg']:.1f}")

# 각 과목의 총점과 평균 계산
total_kor, total_eng, total_math = 0, 0, 0

for student in students:
    total_kor += student['kor']
    total_eng += student['eng']
    total_math += student['math']

avg_kor = total_kor / len(students)
avg_eng = total_eng / len(students)
avg_math = total_math / len(students)

print("==============================")
print(f"총점/평균 {total_kor}/{avg_kor:.1f} {total_eng}/{avg_eng:.1f} {total_math}/{avg_math:.1f}")