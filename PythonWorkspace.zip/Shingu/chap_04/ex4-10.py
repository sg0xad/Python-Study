import random
import string

# 알파벳 소문자와 숫자를 포함한 문자열 생성
characters = string.ascii_lowercase + string.digits

# 문자열에서 랜덤으로 3개의 문자 선택
password = ''.join(random.choice(characters) for _ in range(3))

print("생성된 패스워드:", password)