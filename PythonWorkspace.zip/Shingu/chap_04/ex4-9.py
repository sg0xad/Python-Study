from turtle import Turtle

# Turtle 객체 생성
t = Turtle()
t.shape("turtle")

# 첫 번째 색상과 좌표 입력 받기
color1 = input("색상 #1을 입력하시오: ")
x1 = int(input("x 좌표 #1을 입력하시오: "))
y1 = int(input("y 좌표 #1을 입력하시오: "))

# 두 번째 색상과 좌표 입력 받기
color2 = input("색상 #2을 입력하시오: ")
x2 = int(input("x 좌표 #2을 입력하시오: "))
y2 = int(input("y 좌표 #2을 입력하시오: "))

# 세 번째 색상과 좌표 입력 받기
color3 = input("색상 #3을 입력하시오: ")
x3 = int(input("x 좌표 #3을 입력하시오: "))
y3 = int(input("y 좌표 #3을 입력하시오: "))

# 첫 번째 색상으로 설정 후 첫 번째 위치로 이동 및 스템 찍기
t.color(color1)
t.penup()
t.goto(x1, y1)
t.stamp()

# 두 번째 색상으로 설정 후 두 번째 위치로 이동 및 스템 찍기
t.color(color2)
t.goto(x2, y2)
t.stamp()

# 세 번째 색상으로 설정 후 세 번째 위치로 이동 및 스템 찍기
t.color(color3)
t.goto(x3, y3)
t.stamp()