from turtle import Turtle

# Turtle 객체 생성
t = Turtle()
t.shape("turtle")

# 좌표 리스트 초기화
coords = []

# 3개의 좌표 입력 받기
for _ in range(3):
    x = int(input("x 좌표를 입력하시오: "))
    y = int(input("y 좌표를 입력하시오: "))
    coords.append((x, y))

# 첫 번째 좌표로 이동
t.penup()
t.goto(coords[0][0], coords[0][1])
t.pendown()

# 두 번째 좌표로 이동
t.goto(coords[1][0], coords[1][1])

# 세 번째 좌표로 이동
t.goto(coords[2][0], coords[2][1])