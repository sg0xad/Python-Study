# 3명의 학생의 국영수 점수와 총점, 평균을 list에 저장하고 서식에 맞춰 출력

total = []
cnt = 3

for i in range(cnt):
    one = []  # 한명의 학생의 정보를 저장한 리스트 초기화
    one.append(input(f"{i + 1}번째 학생 성명:"))
    one.append(int(input(str(i + 1) + "번째 학생 국어점수:")))
    one.append(int(input(str(i + 1) + "번째 학생 영어점수:")))
    one.append(int(input(str(i + 1) + "번째 학생 수학점수:")))
    one.append(one[1] + one[2] + one[3])  # 총점
    one.append(one[4] / cnt)  # 평균
    total.append(one)  # 전체 학생의 정보를 저장하는 리스트에 한명의 정보 추가

print("결과출력\n")
for i in range(cnt):
    print("%10s %3d %3d %3d %5.1f %3.1f\n" % (
    total[i][0], total[i][1], total[i][2], total[i][3], total[i][4], total[i][5]))