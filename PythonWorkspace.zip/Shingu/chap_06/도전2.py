# import random
#
# while True:
#     x = random.randint(1, 100)
#     y = random.randint(1, 100)
#     print(x, "+", y, "=", end= " ")
#     answer = int(input())
#     if answer == x + y:
#         print("잘했어요!!")
#     else:
#         print("다음번에는 잘할 수 있죠?")

# 덧셈 뿐만 아니라 뺄셈 문제도 출제할 수 있도록 위의 프로그램을 수정하라.

import random

while True:
    x = random.randint(1, 100)
    y = random.randint(1, 100)

    # 연산자 선택 (0: 덧셈, 1: 뺄셈)
    op = random.randint(0, 1)

    if op == 0:  # 덧셈
        print(x, "+", y, "=", end=" ")
        answer = int(input())
        if answer == x + y:
            print("잘했어요!!")
        else:
            print("다음번에는 잘할 수 있죠?")

    else:  # 뺄셈
        # x가 y보다 크지 않으면 값을 바꾸어 준다.
        if x < y:
            x, y = y, x

        print(x, "-", y, "=", end=" ")
        answer = int(input())

        if answer == x - y:
            print("잘했어요!!")
        else:
            print("다음번에는 잘할 수 있죠?")