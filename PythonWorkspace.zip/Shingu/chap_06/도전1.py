# import random
#
# tries = 0
# guess = 0;
# answer = random.randint(1, 100)
#
# print("1부터 100 사이의 숫자를 맞추시오")
#
# while guess != answer:
#     guess = int(input("숫자를 입력하시오: "))
#     tries = tries + 1
#     if guess < answer:
#         print("낮음!")
#     if guess > answer:
#         print("높음!")
#
# if guess == answer:
#     print("축하합니다. 시도횟수=", tries)
# else:
#     print("정답은 ", answer)

# 시도 횟수를 최대 10번으로 제한하려면 위의 프로그램을 어떻게 변경하여야 하는가?

import random

tries = 0
guess = 0
answer = random.randint(1, 100)

print("1부터 100 사이의 숫자를 맞추시오")

while tries < 10:
    guess = int(input("숫자를 입력하시오: "))
    tries += 1

    if guess < answer:
        print("낮음!")
    elif guess > answer:
        print("높음!")
    elif guess == answer:
        print("축하합니다. 시도횟수=", tries)
        break

if tries == 10 and guess != answer:
    print("정답은 ", answer)